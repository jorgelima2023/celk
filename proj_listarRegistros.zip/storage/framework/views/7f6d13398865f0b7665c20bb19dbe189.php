<?php $__env->startSection('content'); ?>

<h2>Detalhe do curso</h2>
    <a href="<?php echo e(route('courses.index')); ?>">Listar</a><br>
    <a href="<?php echo e(route('courses.edit')); ?>">Editar</a><br>

<?php $__env->stopSection(); ?>


<!-- <!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Celk show curso</title>
</head>
<body>
    <h2>Detalhe do curso</h2>
    <a href="<?php echo e(route('courses.index')); ?>">Listar</a><br>
    <a href="<?php echo e(route('courses.edit')); ?>">Editar</a><br>
</body>
</html> -->
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\celk\resources\views/courses/show.blade.php ENDPATH**/ ?>