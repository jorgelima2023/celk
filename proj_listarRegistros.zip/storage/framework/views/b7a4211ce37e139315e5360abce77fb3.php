<!-- <!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Celk view curso</title>
</head>
<body>
    <h2>Listar os cursos</h2>
    <a href="<?php echo e(route('courses.show')); ?>">Visualizar</a><br>
    <a href="<?php echo e(route('courses.create')); ?>">Cadastrar</a><br>
</body>
</html> -->



<?php $__env->startSection('content'); ?>

<h2>Listar os cursos</h2>
    <a href="<?php echo e(route('courses.show')); ?>">Visualizar</a><br>
    <a href="<?php echo e(route('courses.create')); ?>">Cadastrar</a><br>

    <!-- <p style="color: #f00">listar cursos!</p><br> -->

    <!-- var_dump receber dados -->
    <!-- <?php echo e(dd($courses)); ?> -->


    <?php $__empty_1 = true; $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php echo e($course->id); ?><br>
        <?php echo e($course->name); ?><br>
        <?php echo e(\Carbon\Carbon::parse($course->created_at)->format('d/m/Y H:i:s')); ?><br>
        <?php echo e(\Carbon\Carbon::parse($course->updated_at)->format('d/m/Y H:i:s')); ?><br>
        <hr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p style="color: #f00">Nenhum curso encontrado!</p>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\celk\resources\views/courses/index.blade.php ENDPATH**/ ?>