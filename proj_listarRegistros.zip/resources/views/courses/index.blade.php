<!-- <!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Celk view curso</title>
</head>
<body>
    <h2>Listar os cursos</h2>
    <a href="{{ route('courses.show') }}">Visualizar</a><br>
    <a href="{{ route('courses.create') }}">Cadastrar</a><br>
</body>
</html> -->

@extends('layouts.admin')

@section('content')

<h2>Listar os cursos</h2>
    <a href="{{ route('courses.show') }}">Visualizar</a><br>
    <a href="{{ route('courses.create') }}">Cadastrar</a><br>

    <!-- <p style="color: #f00">listar cursos!</p><br> -->

    <!-- var_dump receber dados -->
    <!-- {{ dd($courses) }} -->


    @forelse ($courses as $course)
        {{ $course->id }}<br>
        {{ $course->name }}<br>
        {{ \Carbon\Carbon::parse($course->created_at)->format('d/m/Y H:i:s') }}<br>
        {{ \Carbon\Carbon::parse($course->updated_at)->format('d/m/Y H:i:s') }}<br>
        <hr>

    @empty
        <p style="color: #f00">Nenhum curso encontrado!</p>
    @endforelse

@endsection
