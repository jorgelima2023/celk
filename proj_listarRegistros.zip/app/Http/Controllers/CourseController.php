<?php

namespace App\Http\Controllers;

use App\Models\Course;
use Illuminate\Http\Request;

class CourseController extends Controller
{
    // listar os cursos
    public function index(){
        // teste        //dd("listar cursos");
        // 'courses' eh o diretorio
        // index eh a index.blade.php

        //return view('courses.index'); // carregar a view

        // recuperar os registros do BD 
        $courses = Course::get();
        //return view('courses.index', ['courses' => $courses]);
        return view('courses.index', ['courses' => $courses]);

    }
    public function show(){           // php artisan make:view courses/show
                                      // php artisan make:view courses/index
        return view('courses.show');  // visualizar o curso
    }
    // carregar o formulario cadastrar novo curso
    public function create(){           // php artisan make:view courses/create
        return view('courses.create');  // cadastrar o curso, view carregar o formulario
    }
    // cadastrar no banco de dados o novo curso
    public function store(Request $request){
        // cadastrar o curso, receber dados  do formulario
        // dd('cadastrar o registro no banco de dados');

        // print_var_info para conferir os dados que estao vindo.
        // dd($request);
        //dd($request->name);

        //********************************************************************************** 
        // google pesquisa documentacao  por 'laravel' 
        //   buscar 'create'
        
        /*
        use App\Models\Post;
 
        $post = Post::find(1);
        
        $comment = $post->comments()->create([
            'message' => 'A new comment.',
        ]);*/

        //********************************************************************************** 

        // Course eh a model
        Course::create([
            'name' => $request->name
        ]);
        // redirecionar o usuario, enviar a mensagem de sucesso!!!
        // 'success' e o nome da sessao , que sera validado no metodo create para apres. msg ao usuario!
        return redirect()->route('courses.create')->with('success', 'Curso cadastrado com sucesso');
    }
    // carregar o formulario editar curso
    public function edit(){  // php artisan make:view courses/edit
        // editar o curso, receber dados  do formulario
        return view('courses.edit');
    }
    // recebe os dados do formulario 
    public function update(){
        // editar dados  no banco de dados
        dd('editar o registro no bd');
    }
    // excluir o curso do banco de dados
    public function destroy(){
        // excluir dados  no banco de dados
        dd('excluir o registro no bd');
    }
}
